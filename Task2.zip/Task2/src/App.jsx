import React from 'react';
import UserCard from './components/UserCard';
import './App.css';

function App() {
  // Array holding 5 user data sets with at least 5 details each
  const users = [
    {
      id: 1,
      name: "Daggu Venkatesh",
      age: 29,
      city: "Hyderabad",
      email: "daggu.venkatesh@example.com",
      phone: "9999999999"
    },
    {
      id: 2,
      name: "Anil",
      age: 34,
      city: "Bangalore",
      email: "anil@example.com",
      phone: "9999999998"
    },
    {
      id: 3,
      name: "Sunil",
      age: 26,
      city: "Chennai",
      email: "sunil@example.com",
      phone: "9999999997"
    },
    {
      id: 4,
      name: "Ramesh",
      age: 41,
      city: "Mumbai",
      email: "ramesh@example.com",
      phone: "9999999996"
    },
    {
      id: 5,
      name: "Suresh",
      age: 30,
      city: "San Francisco",
      email: "suresh@example.com",
      phone: "9999999995"
    }
  ];

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>User Directory</h1>
        <p>Parent component rendering user profiles via props</p>
      </header>

      <main className="user-grid">
        {users.map((user) => (
          <UserCard
            key={user.id}
            name={user.name}
            age={user.age}
            city={user.city}
            email={user.email}
            phone={user.phone}
          />
        ))}
      </main>
    </div>
  );
}

export default App;