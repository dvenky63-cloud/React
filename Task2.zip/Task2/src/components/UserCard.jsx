import React from 'react';
import './UserCard.css';

// Child component accepting props
function UserCard({ name, age, city, email, phone }) {
  return (
    <div className="user-card">
      <h3 className="user-name">{name}</h3>
      <div className="user-details">
        <p><strong>Age:</strong> {age}</p>
        <p><strong>City:</strong> {city}</p>
        <p><strong>Email:</strong> {email}</p>
        <p><strong>Phone:</strong> {phone}</p>
      </div>
    </div>
  );
}

export default UserCard;