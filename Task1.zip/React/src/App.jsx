import SelfIntroduction from './Components/SelfIntroduction.jsx';
import './App.css';

function App() {
  return (
    <main className="app-container">
      <SelfIntroduction />
    </main>
  );
}

export default App;