import './SelfIntroduction.css';

function SelfIntroduction() {
  const profileData = {
    name: "Daggu Venkatesh",
    role: "Full Stack Developer",
    education: "B.Tech in Computer Science and Engineering",
    careerGoal: "To design responsive, low-latency web applications and build resilient distributed systems.",
    skills: [
      "JavaScript (ES6+)",
      "React.js",
      "HTML5 & CSS3",
      "Linux / Bash",
      "Git & GitHub",
      "Networking Fundamentals"
    ],
    experience: [
      {
        title: "Frontend & Backend Developer / Project Contributor",
        place: "Independent Projects",
        period: "2026 - Present",
        description: "Built dynamic web interfaces fetching external REST APIs, state management, and optimized render cycles."
      }
    ],
    hobbies: [
      "Home networking & virtualization (Proxmox, OpenWrt)",
      "Optimizing system workflows & automation scripts"
    ]
  };

  return (
    <article className="intro-card">
      <header className="intro-header">
        <h1 className="intro-name">{profileData.name}</h1>
        <p className="intro-role">{profileData.role}</p>
      </header>

      <section className="intro-section">
        <h2>Career Goal</h2>
        <p>{profileData.careerGoal}</p>
      </section>

      <section className="intro-section">
        <h2>Education</h2>
        <p>{profileData.education}</p>
      </section>

      <section className="intro-section">
        <h2>Skills</h2>
        <ul className="skills-badge-list">
          {profileData.skills.map((skill, index) => (
            <li key={index} className="skill-badge">{skill}</li>
          ))}
        </ul>
      </section>

      <section className="intro-section">
        <h2>Experience</h2>
        {profileData.experience.map((exp, index) => (
          <div key={index} className="exp-item">
            <h3>{exp.title} &mdash; <span>{exp.place}</span></h3>
            <span className="exp-period">{exp.period}</span>
            <p>{exp.description}</p>
          </div>
        ))}
      </section>

      <section className="intro-section">
        <h2>Hobbies & Interests</h2>
        <ul className="bullet-list">
          {profileData.hobbies.map((hobby, index) => (
            <li key={index}>{hobby}</li>
          ))}
        </ul>
      </section>
    </article>
  );
}

export default SelfIntroduction;